/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part_1;

import java.util.Scanner;

/**
 *
 * @author tnc98
 */
public class main {
   public static void main(String[] args) {
    int age =0;
        String catagory = "";
       String exersize = "";
       String feedback = "";
        Scanner scan = new Scanner(System.in);
        Scanner scan1 = new Scanner(System.in);
        Scanner scan2 = new Scanner(System.in);
        System.out.println("What is your childs age in months?");
       age = scan.nextInt();
       
       
       System.out.println("What catagory do you wish to work on?");
       catagory = scan1.nextLine();
       if(age<9 & catagory.equals("gross motor"))
           exersize ="roll on stomach";
       System.out.println("your child is " + age + " and you wish to work on " + catagory + " here is an exersize " + "\n"+ exersize  + "\n");
       System.out.println("how did your child do");
       feedback = scan2.nextLine();
       if(feedback.equals("a"))
       {
           System.out.println("move onto next milestone");
       }
        if(feedback.equals("b"))
        {
           System.out.println("stay on current milestone");
        }
        if(feedback.equals("c"))
        {
           System.out.println("here is another exersize");
        }
       
   }
   }
    

